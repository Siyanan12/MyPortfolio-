const image=document.querySelector('#images');
const button=document.querySelector('#mybutton');
mybutton.onclick=()=>{
    let imagesource=image.getAttribute('src');
    if (imagesource=='imagess/IMG_6497.PNG'){
        image.setAttribute('src','imagess/IMG_6550.PNG');
    }
    else{
        image.setAttribute('src','imagess/IMG_6497.PNG');
    };
};
function calcfunction(){
let num1 =parseFloat(document.getElementById("num1").value);
let num2 =parseFloat(document.getElementById("num2").value);
let operation =  document.getElementById('operation').value;
let result;
//step 2- do the calclculation based on the operation 
//use a switch block to check the value of a single variable
//across different values
if (isNaN(num1)|| isNaN(num2))
  {
  result="enter numbers please";
 }
else{
switch(operation){
case 'add': result= num1+num2;
break;
case 'sub': result= num1-num2;
break;

default:
  result="invalid operation";
}
}

//step 3 assign the result to the result text box
document.getElementById('result').value = result;
}
